/*Quine-McCluskey implementation by
Arkajit De 14/CSE/20
Joyjit Choudhury 14/CSE/33
Arijit Chatterjee 14/CSE/43
*/
#include<iostream>
#include<string.h>
#include<math.h>
#include<stdlib.h>
 using namespace std;
 int *lng1=new int[5000];
 int *lng2=new int[5000];
 int *rw2=new int[5000];
 int *rw1 =new int[5000];
 int compare(int**,int ,int,int,int);//for creation of tables and selection of minterms
 int col_dom(int **,int ,int );//for column dominance
 int row_dom(int **,int ,int );//for row dominance
 int **m=new int*[5000];//for first tables
 int **m1=new int*[5000];//for binary form of implcants
 int **m2=new int*[5000];//for second and last table
 int **pch=new int*[5000];//pi chart
 int *es=new int[5000];// prime implicants
 int *es1=new int[5000];//essential prime implicants
 int *nes=new int[5000];//all prime implicants
 int *mes=new int[5000];//non-essential prime implicants
 int ns=0,ms=0,c=0,sl,sv,i,sum,sc1,sc2,sv1,sv2;

 int main()
 {

 	int n,min,i,j,k,s,sk,sz=1,q=0,x=1,x1=1,r=0,h,ctr,t,y,f=0,mk=0,roll,choice;
 	cout<<"Enter number of variables:: ";//for variables
 	cin>>n;
 	cout<<"\n";
 	cout<<"Enter number of minterms for minimization:: ";//number of terms
 	cin>>min;
 	sl=min;
 	sv=(n+3);
	cout<<"User input of minterms\n";
 	int *grp= new int[min];
 	cout<<"Enter terms:: ";// manually input of terms
 	for(i=0;i<min;i++)
 	cin>>grp[i];
 	cout<<"Minterms are:\n";
 	for(i=0;i<min;i++)
 	cout<<grp[i]<<" ";
 	cout<<"\n";
    int*ct =new int[5000];
    	for(i=0;i<5000;i++)
    {
    	m[i]=new int[5000];
    	m2[i]=new int[5000];
    	m1[i]=new int[5000];
    }

    for(i=0;i<5000;i++)
    {
    	for(j=0;j<5000;j++)
    	{
    		m1[i][j]=0;
    		m[i][j]=0;
    	}

    }
    int bin;
    for(i=0;i<min;i++)
    m[i][0]=grp[i];

    for(i=0;i<min;i++)//binary conversion of implicants
  {
	j=n;bin=grp[i];
	while(bin>0)
      {
      	m[i][j]=bin%2;
      	j--;
       bin=bin/2;
      }
  }
    int c;
   for(i=0;i<5000;i++)
  {
    c=0;
	for(j=1;j<5000;j++)
	{
		c+=m[i][j];
	}
	ct[i]=c;
   }

   for(i=0;i<min;i++)
   {
   m[i][n+1]=ct[i];
   }

    s=compare(m,sl,sv,n,sz);//calling of comp function for creating tables
      if(s==1)
   {
     while(1)
    {   sz*=2;
        s=compare(m,sc1,sc2,n,sz);
    	if(s==2)
    	break;
    }
  }
  mk=0;
   for(i=0;i<sc1;i++)// creation of pi-chart and saving values in m1
    {   if(m[i][1]!=0||sz==1)
	   	{
	   	  if(m[i][n+sz+1]==0)
	   	  {
	   	     x=1;
			 q++;
			 m1[mk][0]=mk+1;
			 for(h=sz;h<sz+n;h++)
			 m1[mk][x++]=m[i][h];
			 mk++;
	   	  }
        }

    }
    for(i=0;i<sv1;i++)//for rest of values
    {
    	if(m2[i][1]!=0)
    	{
    	    x1=1;
    		r++;
    		m1[mk][0]=mk+1;
    		for(h=sz*2;h<sz*2+n;h++)
    		m1[mk][x1++]=m2[i][h];
    		mk++;
    	}

    }
    for(i=0;i<(q+r+2);i++)
    {
    	pch[i]=new int[min+2];
    }

    for(i=0;i<(q+r+2);i++)//inseting points in pi-chart
    {
    	for(j=0;j<min+2;j++)
    	pch[i][j]=0;
    }
     for(j=1;j<min+1;j++)
     pch[0][j]=grp[j-1];
     for(i=1;i<(q+r+1);i++)
     pch[i][0]=i;

     for(i=1,j=0;i<r+1;j++)//inserting 1 in place of cross in pi-chart for prime implicants in last table
     {
      if(m2[j][1]!=0)
       {
     	for(h=0;h<sz*2;h++)
     	{
         for(k=1;k<min+1;k++)
     	  {
     		if(m2[j][h]==pch[0][k])
     		{
     		pch[i][k]=1;
     		}
     	  }
     	}
     	i++;
       }
     }
     for(i=r+1,j=0;i<q+r+1;j++)//inserting 1 in place of cross in pi-chart for prime implicants in second last table
     {
		 if(m[j][1]!=0||sz==1)
		 {

		   if(m[j][n+sz+1]==0)
     	  {
     		for(h=0;h<sz;h++)
     		{
  			for(k=1;k<min+1;k++)
         	 {
     		  if(m[j][h]==pch[0][k])
     			{
     			pch[i][k]=1;
     			}
         	 }
     		}
     	  i++;
          }
         }
      }

     t=0;
     for(i=1;i<min+1;i++)//selection of essential prime implicants
     {   ctr=0;
     	for(j=1;j<q+r+1;j++)
     	{
     	   if(pch[j][i]==1)
     		{
     		  ctr++;
     		  sk=j;
     	    }
     	}
     	if(ctr==1)
     	{
     	     es[t]=sk;
     	     t++;
     	}
     }
     y=0;
      for(i=0;i<t;i++)
      {  ctr=0;
      	for(j=i+1;j<t;j++)
      	{
      		if(es[i]==es[j])
      		ctr++;

      	}
      	if(ctr==0)
      	{
      		es1[y]=es[i];//essential prime implicants
      		y++;
      	}
      }
      int l;
     sv= min+2;
     sl=q+r+2;

    if(y>0)
    {
    	for(i=0;i<y;i++)
    {
    	for(j=1;j<sv-2;j++)
    	{
    		if(pch[es1[i]][j]==1)
    		{
    			pch[sl-1][j]=1;
    		}
    	}
    }
     for(i=1;i<sl-1;i++)
     {   ctr=0;
     	for(j=1;j<sv-2;j++)
     	{
     		if(pch[sl-1][j]==0&&pch[i][j]==1)
     		ctr++;
     	}
     	if(ctr==0)
     	pch[i][sv-1]=1;
     }


    sum=0;
    for(i=1;i<(sl-1);i++)
    {
    	sum+=pch[i][sv-1];
    }

	if(sum!=sl-2)//checking for row and coloumn dominance
	{   l=col_dom(pch,sl,sv);//row dominance
		r=row_dom(pch,sl,sv);//coloum dominance
		while(!(r==0||(r==0&&l==0)))
		{
		  l=col_dom(pch,sl,sv);
		  r=row_dom(pch,sl,sv);
		}
     }
    }
    ns=0;
    for(i=0;i<q+r+2;i++)
    {
    	if(pch[i][sl-1]==0)
    	nes[ns++]=pch[i][0];//non essential prime implicants
    }

    for(i=0;i<ns;i++)//removing dublicates
    {
      c=0;
    	for(j=0;j<y;j++)
    	{
    		if(nes[i]==es1[j])
    		{
    			c=1;
    			break;
    		}
    	}
    	if(c==0)
    	mes[ms++]=nes[i];
    }
   ns=0;
   for(i=0;i<y;i++)
   	nes[ns++]=es1[i];
   for(i=0;i<ms;i++)
   nes[ns++]=mes[i];
   cout<<"\n";
   cout<<"Minimized terms are:";
   cout<<"\n";
   r=0;
   for(i=0;i<ns;i++)//for conversion from binary to terms
   {
   	for(j=0;j<mk;j++)
   	{
   		if(nes[i]==m1[j][0])
   		{  if(r!=0)
   		   cout<<" + ";
   		   r++;
		   	for(h=1;h<=n;h++)
          	{
          		if(m1[j][h]==0)
          		cout<<char(65+h-1)<<"'";
          		else if(m1[j][h]==1)
          		cout<<char(65+h-1);
          	}
		 }
   	  }
   }
  return 0;
 }


int compare(int **m,int sl,int sv,int n,int sz)//It compares and creates tables
 {

	int i,j,k,d,e,ctr,a=0,w,x,h,c,pt,g,q,f=0,b;
    for(i=0;i<5000;i++)
    {
    	for(j=0;j<5000;j++)
    	m2[i][j]=0;
    }
    k=n+sz;
    for(i=0;i<sl;i++)
    {
    	for(j=0;j<sl;j++)
    	{   ctr=0;
    		if(m[i][k]==m[j][k]-1)
    		{    d=i,e=j;
    			for(h=sz;h<n+sz;h++)
    			{
    				if(m[i][h]!=m[j][h])
    				ctr++;
    			}
    			if(ctr==1)
    			{
    			     m[i][n+sz+1]=1; // selecting primne implicants
    			     m[j][n+sz+1]=1;
    			    pt=0;
    				for(b=0;b<2;b++)
    				{
    					for(c=0;c<sz;c++)
    					{
    						m2[a][pt]=m[d][c];

    						pt++;


    					}
    					d=e;
    				}

    				w=2*sz;
    					for(x=sz;x<n+sz;x++)
    					{
    						if(m[i][x]!=m[j][x])
    						{
    						    m2[a][w]=m[j][x]+1;
    						    w++;
    				     	}
    						else
    						{
    						   m2[a][w]=m[j][x];
    						   w++;
    					    }
    					}
    					m2[a][w]=m[j][n+sz]+10;//insert new group no in new table;
    					w++;
    					a++;
    			}
    			else
    			continue;
    		}

    	}
    }

   for(i=0;i<a;i++)
    {
    	for(j=i+1;j<a;j++)
    	{    ctr=0;
    		for(h=sz*2;h<(sz*2+n);h++)
    		{
    		     if(m2[i][h]!=m2[j][h])
    		     ctr++;
    		}
    		if(ctr==0)
    		for(h=0;h<w+1;h++)
    		m2[j][h]=0;
    	}
    }

   sz*=2;   // creation for next table
   k=n+sz;
    for(i=0;i<a;i++)
    {
    	for(j=0;j<a;j++)
    	{   ctr=0;
    		if(m2[i][k]==m2[j][k]-1)
    		{
    			for(h=sz;h<n+sz;h++)
    			{
    				if(m2[i][h]!=m2[j][h])
    				ctr++;
    			}
    			if(ctr==1)
    			{
    			        for(i=0;i<5000;i++)//coming back for next table
                        {
    	                   for(j=0;j<5000;j++)
    	                   m[i][j]=0;
                        }
                        g=0;
                        for(i=0;i<a;i++)
                        {

                        	{   g++;
                        	   for(j=0;j<w+1;j++)
                        	   m[i][j]=m2[i][j];
                            }
                        }

                      f=1;
                      break;
    			}
           }

      }
	  if(f==1)
           break;
    }
    if(f==1)
    {
    	sc1=g;
        sc2=w+1;
        sv1=a;
        sv2=w+1;
        return 1;
    }
    else
    {
	  sc1=sl;
	  sc2=sv;
      sv1=a;
      sv2=w+1 ;
	  return 2;
    }
}


int col_dom(int **pch,int sl,int sv)//for column dominace
{
	int i,j,k,l,l1,ctr,ctr1,ctr2,m,n,f=0,z;
	for(i=1;i<(sv-2);i++)
  {      l=0,ctr=0;
		if(pch[sl-1][i]==0)
		{
			for(j=1;j<(sl-1);j++)
			{
				if(pch[j][i]==1&&pch[j][sv-1]==0)
				{
				    ctr++;
			     	lng1[l]=j;
			     	l++;
			    }
			}
			for(k=i+1;k<(sv-2);k++)
			{    l1=0,ctr1=0;
				if(pch[sl-1][k]==0)
				{
					for(m=1;m<(sl-1);m++)
					{
						if(pch[m][k]==1&&pch[m][sv-1]==0)
						{
						  ctr1++;
						   lng2[l1]=m;
						   l1++;
					    }
					}


			       if(l>l1)
			       {   ctr2=0;
				      for(n=0;n<l1;n++)
				    {
				       for(z=0;z<l;z++)
				       {
				       	if(lng2[n]==lng1[z])
				       	ctr2++;
				       }

				    }
				     if(ctr2==l1)
				    {
					   pch[sl-1][i]=1;
					   f=1;
			     	}
		 	       }
		 	       else if(l<l1)
		 	       {
		 	       	  ctr2=0;
				      for(n=0;n<l;n++)
				    {
				       for(z=0;z<l1;z++)
				       {
				       	if(lng1[n]==lng2[z])
				       	ctr2++;
				       }

				    }
				     if(ctr2==l)
				    {
					   pch[sl-1][k]=1;
					   f=1;
			     	}
		 	       }
		       }

		   }
        }
  }
	for(i=1;i<sl-1;i++)//making coloumn dead
     {   ctr=0;
     	for(j=1;j<sv-2;j++)
     	{
     		if(pch[sl-1][j]==0&&pch[i][j]==1)
     		ctr++;
     	}
     	if(ctr==0)
     	pch[i][sv-1]=1;
     }
	if(f==1)
	{
	     sum=0;
    for(i=1;i<(sl-1);i++)
    {
    	sum+=pch[i][sv-1];
    }
	if(sum==sl-2)
	return sum;
	else
	return 1;
	}
	else
	return 0;

}

int row_dom(int **pch,int sl,int sv)//for row dominance
{
	int i,j,k,l,f,n,f1,f2,m,r,rk,ctr,ip;
	for(i=1;i<(sl-1);i++)
	{
	    if(pch[i][sv-1]==0)

	  {
	    r=0,f=0;
		for(j=1;j<(sv-2);j++)
		{
			if(pch[i][j]==1&&pch[sl-1][j]==0)
			{
				rw1[r]=j;
				r++;
				f=1;
			}
		}
		if(f==1)
		{
		for(k=i+1;k<(sl-1);k++)
		{     if(pch[k][sv-1]==0)
	      {
		    rk=0,f1=0,ctr=0;
		     for(m=1;m<(sv-2);m++)
			  {
			  if(pch[k][m]==1&&pch[sl-1][m]==0)
			     {
				   rw2[rk]=m;
			  	   rk++;
			  	   f1=1;
			     }
			  }
			  if(f1==1)
			  {
			  	if(rk>r)
			  	{
			  		for(n=0;n<r;n++)//making row dead
			  		{
						for(ip=0;ip<rk;ip++)

						  {
						    if(rw1[n]==rw2[ip])
			  			     ctr++;
			  			}
			  		}
			  		if(ctr==r)
			  		{
			  			pch[i][sv-1]=1;
			  			f2=1;

			  		}
			  	}else if(rk<r)
			  	{
			  	for(n=0;n<rk;n++)
			  	 {
			  	  for(ip=0;ip<r;ip++)
					{
					   if(rw2[n]==rw1[ip])
			  		   ctr++;
			  		}
			  	 }
			  	 if(ctr==rk)
			  	  {
			  		pch[k][sv-1]=1;
			  		f2=1;
			  	  }
			  	}
			  }
	    	}
          }

	    }
      }
	}
	if(f2==1)
	{
	sum=0;
    for(i=1;i<(sl-1);i++)
    {
    	sum+=pch[i][sv-1];
    }
	if(sum==sl-2)
      return sum;
      else
      return 1;
	}
	else
	return 0;
}

