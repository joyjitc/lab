                   Quine McCluskey- logic Minimization
                 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This is a readme of c++ program for the implementation of Quine McCluskey Logic Minimization.

                    -Arkajit De, Roll No.- 14/CS/20,3rd-sem, CSE Department, NIT DURGAPUR

		    -Joyjit Choudhury, Roll No.- 14/CS/33,3rd-sem, CSE Department, NIT DURGAPUR

		    -Arjit Chatterjee, Roll No.- 14/CS/43,3rd-sem, CSE Department, NIT DURGAPUR	

# About the program-
  *this program can solve more than 10 variable logic minimization. 
  *program doesnot satisfy for cyclic,semi cyclic and don't care cases.
# Features-
  *the whole concept is based on dynamic programming.
  *three essential function in the code-
   1.compare-it compares and dynamincally creates tables until there is no more comparision.
   2.col_dom-it checks for coloumn dominance.
   3.row_dom-it checks for row dominance.
  *program creates a new table an delete the older one taking all the values required.
  *the program also creates the pi-chart dynammically and manipulates on it.
# Input-
   *First take number of variables
   *Enter number of minterms
    *Then enter the decimal minterms